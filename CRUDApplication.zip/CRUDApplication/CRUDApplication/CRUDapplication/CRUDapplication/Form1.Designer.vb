﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        btnSame = New Button()
        btnDelete = New Button()
        btnAdd = New Button()
        btnUpdate = New Button()
        txtAddress = New TextBox()
        Label5 = New Label()
        txtLastName = New TextBox()
        Label4 = New Label()
        txtFirstName = New TextBox()
        Label3 = New Label()
        txtID = New TextBox()
        Label2 = New Label()
        Label1 = New Label()
        Panel2 = New Panel()
        dgv = New DataGridView()
        txtSearch = New TextBox()
        btnSearch = New Button()
        Panel3 = New Panel()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        CType(dgv, ComponentModel.ISupportInitialize).BeginInit()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.MistyRose
        Panel1.Controls.Add(btnSame)
        Panel1.Controls.Add(btnDelete)
        Panel1.Controls.Add(btnAdd)
        Panel1.Controls.Add(btnUpdate)
        Panel1.Controls.Add(txtAddress)
        Panel1.Controls.Add(Label5)
        Panel1.Controls.Add(txtLastName)
        Panel1.Controls.Add(Label4)
        Panel1.Controls.Add(txtFirstName)
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(txtID)
        Panel1.Controls.Add(Label2)
        Panel1.Location = New Point(8, 93)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(544, 555)
        Panel1.TabIndex = 0
        ' 
        ' btnSame
        ' 
        btnSame.BackColor = SystemColors.ActiveBorder
        btnSame.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnSame.Location = New Point(249, 448)
        btnSame.Name = "btnSame"
        btnSame.Size = New Size(136, 54)
        btnSame.TabIndex = 11
        btnSame.Text = "SAVE"
        btnSame.UseVisualStyleBackColor = False
        ' 
        ' btnDelete
        ' 
        btnDelete.BackColor = SystemColors.ActiveBorder
        btnDelete.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnDelete.Location = New Point(58, 448)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(136, 54)
        btnDelete.TabIndex = 10
        btnDelete.Text = "DELETE"
        btnDelete.UseVisualStyleBackColor = False
        ' 
        ' btnAdd
        ' 
        btnAdd.BackColor = SystemColors.ActiveBorder
        btnAdd.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnAdd.Location = New Point(55, 349)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(136, 54)
        btnAdd.TabIndex = 8
        btnAdd.Text = "ADD"
        btnAdd.UseVisualStyleBackColor = False
        ' 
        ' btnUpdate
        ' 
        btnUpdate.BackColor = SystemColors.ActiveBorder
        btnUpdate.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnUpdate.Location = New Point(249, 349)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(136, 54)
        btnUpdate.TabIndex = 9
        btnUpdate.Text = "UPDATE"
        btnUpdate.UseVisualStyleBackColor = False
        ' 
        ' txtAddress
        ' 
        txtAddress.Location = New Point(177, 262)
        txtAddress.Name = "txtAddress"
        txtAddress.Size = New Size(298, 31)
        txtAddress.TabIndex = 7
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.Location = New Point(58, 261)
        Label5.Name = "Label5"
        Label5.Size = New Size(97, 30)
        Label5.TabIndex = 6
        Label5.Text = "Address"
        ' 
        ' txtLastName
        ' 
        txtLastName.Location = New Point(177, 195)
        txtLastName.Name = "txtLastName"
        txtLastName.Size = New Size(298, 31)
        txtLastName.TabIndex = 5
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(55, 194)
        Label4.Name = "Label4"
        Label4.Size = New Size(116, 30)
        Label4.TabIndex = 4
        Label4.Text = "LastName"
        ' 
        ' txtFirstName
        ' 
        txtFirstName.Location = New Point(177, 115)
        txtFirstName.Name = "txtFirstName"
        txtFirstName.Size = New Size(298, 31)
        txtFirstName.TabIndex = 3
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(55, 114)
        Label3.Name = "Label3"
        Label3.Size = New Size(119, 30)
        Label3.TabIndex = 2
        Label3.Text = "FirstName"
        ' 
        ' txtID
        ' 
        txtID.Location = New Point(177, 35)
        txtID.Name = "txtID"
        txtID.Size = New Size(298, 31)
        txtID.TabIndex = 1
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(55, 34)
        Label2.Name = "Label2"
        Label2.Size = New Size(36, 30)
        Label2.TabIndex = 0
        Label2.Text = "ID"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(502, 13)
        Label1.Name = "Label1"
        Label1.Size = New Size(252, 38)
        Label1.TabIndex = 1
        Label1.Text = "CRUD Application"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.MistyRose
        Panel2.Controls.Add(dgv)
        Panel2.Controls.Add(txtSearch)
        Panel2.Controls.Add(btnSearch)
        Panel2.Location = New Point(567, 93)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(734, 553)
        Panel2.TabIndex = 2
        ' 
        ' dgv
        ' 
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv.Location = New Point(25, 113)
        dgv.Name = "dgv"
        dgv.RowHeadersWidth = 62
        dgv.RowTemplate.Height = 33
        dgv.Size = New Size(689, 404)
        dgv.TabIndex = 13
        ' 
        ' txtSearch
        ' 
        txtSearch.Location = New Point(198, 33)
        txtSearch.Name = "txtSearch"
        txtSearch.Size = New Size(298, 31)
        txtSearch.TabIndex = 12
        ' 
        ' btnSearch
        ' 
        btnSearch.BackColor = SystemColors.ActiveBorder
        btnSearch.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnSearch.Location = New Point(15, 28)
        btnSearch.Name = "btnSearch"
        btnSearch.Size = New Size(136, 41)
        btnSearch.TabIndex = 12
        btnSearch.Text = "SEEARCH"
        btnSearch.UseVisualStyleBackColor = False
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.MistyRose
        Panel3.Controls.Add(Label1)
        Panel3.Location = New Point(8, 9)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(1293, 78)
        Panel3.TabIndex = 12
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.RosyBrown
        ClientSize = New Size(1313, 658)
        Controls.Add(Panel3)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Name = "Form1"
        Text = "Form1"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(dgv, ComponentModel.ISupportInitialize).EndInit()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtID As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnSame As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents dgv As DataGridView
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents Panel3 As Panel
End Class
