﻿Imports System.Data.OleDb

Public Class Form1
    Dim conn As New OleDbConnection
    Dim cmd As New OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)
    Dim dset As New DataSet

    Private Sub ShowData()
        conn.Open()
        cmd = conn.CreateCommand()
        cmd.CommandType = CommandType.Text

        If dt IsNot Nothing Then
            dt.Clear()
        Else
            dt = New DataTable()
        End If
        da = New OleDbDataAdapter("SELECT * FROM tblCRUD", conn)
        da.Fill(dt)
        dgv.DataSource = dt
        conn.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim connString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\GWEN PROGRAMMING\PROGRAMMING\VB.NET\CC103 PROJECT FINAL\CRUDapplication\dbCRUDApplicatiom.accdb"
        conn.ConnectionString = connString
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        ShowData()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim ID As String = txtID.Text
        Dim firstname As String = txtFirstName.Text
        Dim lastname As String = txtLastName.Text
        Dim address As String = txtAddress.Text

        Try
            conn.Open()
            Dim queryInsert As String = "INSERT INTO tblCRUD([ID], [First Name], [Last Name], [Address]) VALUES(@ID, @FirstName, @LastName, @Address)"
            cmd = New OleDbCommand(queryInsert, conn)
            cmd.Parameters.AddWithValue("@ID", ID)
            cmd.Parameters.AddWithValue("@FirstName", firstname)
            cmd.Parameters.AddWithValue("@LastName", lastname)
            cmd.Parameters.AddWithValue("@Address", address)
            cmd.ExecuteNonQuery()
            conn.Close()
            ShowData()

            txtID.Text = ""
            txtFirstName.Text = ""
            txtLastName.Text = ""
            txtAddress.Text = ""
            MsgBox("Successfully Added", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Notification")

        Catch ex As Exception
            MessageBox.Show("Error adding data: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If dgv.SelectedRows.Count > 0 Then
            Dim selectedRowIndex As Integer = dgv.SelectedRows(0).Index
            Dim selectedID As String = dgv.Rows(selectedRowIndex).Cells("ID").Value.ToString()

            Try
                conn.Open()
                Dim queryDelete As String = "DELETE FROM tblCRUD WHERE ID = @ID"
                cmd = New OleDbCommand(queryDelete, conn)
                cmd.Parameters.AddWithValue("@ID", selectedID)
                cmd.ExecuteNonQuery()
                conn.Close()
                ShowData()
                MsgBox("Record Deleted", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Notification")
            Catch ex As Exception
                MessageBox.Show("Error deleting record: " & ex.Message)
                conn.Close()
            End Try
        Else
            MessageBox.Show("Please select a row to delete.")
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If dgv.SelectedRows.Count > 0 Then

            Dim selectedID As String = txtID.Text
            Dim updatedFirstName As String = txtFirstName.Text
            Dim updatedLastName As String = txtLastName.Text
            Dim updatedAddress As String = txtAddress.Text

            Try
                conn.Open()
                Dim queryUpdate As String = "UPDATE tblCRUD SET [First Name] = @FirstName, [Last Name] = @LastName, [Address] = @Address WHERE ID = @ID"
                cmd = New OleDbCommand(queryUpdate, conn)
                cmd.Parameters.AddWithValue("@FirstName", updatedFirstName)
                cmd.Parameters.AddWithValue("@LastName", updatedLastName)
                cmd.Parameters.AddWithValue("@Address", updatedAddress)
                cmd.Parameters.AddWithValue("@ID", selectedID)
                cmd.ExecuteNonQuery()
                conn.Close()
                ShowData()
                MsgBox("Record Updated", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Notification")
            Catch ex As Exception
                MessageBox.Show("Error updating record: " & ex.Message)
                conn.Close()
            End Try
        Else
            MessageBox.Show("Please select a row to update.")
        End If
    End Sub

    Private Sub btnSame_Click(sender As Object, e As EventArgs) Handles btnSame.Click
        Try
            conn.Open()
            da.Update(dt)
            conn.Close()
            MsgBox("Changes Saved Successfully", MsgBoxStyle.Information, "Save")
        Catch ex As Exception
            MessageBox.Show("Error saving changes: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim searchText As String = txtSearch.Text.Trim()

        If searchText <> "" Then
            Try
                conn.Open()
                Dim querySearch As String = "SELECT * FROM tblCRUD WHERE [First Name] LIKE @SearchText OR [Last Name] LIKE @SearchText OR [Address] LIKE @SearchText"
                cmd = New OleDbCommand(querySearch, conn)
                cmd.Parameters.AddWithValue("@SearchText", "%" & searchText & "%")

                Dim dtSearch As New DataTable()
                dtSearch.Load(cmd.ExecuteReader())
                dgv.DataSource = dtSearch

                conn.Close()

                If dtSearch.Rows.Count = 0 Then
                    MsgBox("No matching records found.", MsgBoxStyle.Information, "Search")
                Else
                    MsgBox(dtSearch.Rows.Count & " record(s) found.", MsgBoxStyle.Information, "Search")
                End If
            Catch ex As Exception
                MessageBox.Show("Error searching records: " & ex.Message)
                conn.Close()
            End Try
        Else
            MessageBox.Show("Please enter a search term.", "Search")
        End If
    End Sub
End Class
