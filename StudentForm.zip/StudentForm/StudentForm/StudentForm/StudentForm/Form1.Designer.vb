﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        GroupBox1 = New GroupBox()
        Label4 = New Label()
        txtContact = New TextBox()
        Label3 = New Label()
        txtAddress = New TextBox()
        txtAge = New TextBox()
        Label2 = New Label()
        txtName = New TextBox()
        Label1 = New Label()
        dgv = New DataGridView()
        txtEnterId = New TextBox()
        Label5 = New Label()
        btnSearch = New Button()
        btnDelete = New Button()
        btnAdd = New Button()
        btnUpdate = New Button()
        btnEdit = New Button()
        btnSave = New Button()
        GroupBox1.SuspendLayout()
        CType(dgv, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' GroupBox1
        ' 
        GroupBox1.BackColor = Color.OldLace
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(txtContact)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(txtAddress)
        GroupBox1.Controls.Add(txtAge)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Controls.Add(txtName)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Font = New Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point)
        GroupBox1.Location = New Point(38, 34)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(1098, 266)
        GroupBox1.TabIndex = 0
        GroupBox1.TabStop = False
        GroupBox1.Text = "STUDENT FORM"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Sitka Display", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(36, 178)
        Label4.Name = "Label4"
        Label4.Size = New Size(154, 52)
        Label4.TabIndex = 7
        Label4.Text = "Address:"
        ' 
        ' txtContact
        ' 
        txtContact.BorderStyle = BorderStyle.FixedSingle
        txtContact.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txtContact.Location = New Point(720, 193)
        txtContact.Name = "txtContact"
        txtContact.Size = New Size(347, 45)
        txtContact.TabIndex = 6
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Sitka Display", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(578, 186)
        Label3.Name = "Label3"
        Label3.Size = New Size(147, 52)
        Label3.TabIndex = 5
        Label3.Text = "Contact:"
        ' 
        ' txtAddress
        ' 
        txtAddress.BorderStyle = BorderStyle.FixedSingle
        txtAddress.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txtAddress.Location = New Point(201, 186)
        txtAddress.Name = "txtAddress"
        txtAddress.Size = New Size(347, 45)
        txtAddress.TabIndex = 4
        ' 
        ' txtAge
        ' 
        txtAge.BorderStyle = BorderStyle.FixedSingle
        txtAge.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txtAge.Location = New Point(720, 64)
        txtAge.Name = "txtAge"
        txtAge.Size = New Size(347, 45)
        txtAge.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Sitka Display", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(616, 64)
        Label2.Name = "Label2"
        Label2.Size = New Size(98, 52)
        Label2.TabIndex = 2
        Label2.Text = "Age: "
        ' 
        ' txtName
        ' 
        txtName.BorderStyle = BorderStyle.FixedSingle
        txtName.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txtName.Location = New Point(201, 56)
        txtName.Name = "txtName"
        txtName.Size = New Size(347, 45)
        txtName.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Sitka Display", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(78, 48)
        Label1.Name = "Label1"
        Label1.Size = New Size(130, 52)
        Label1.TabIndex = 0
        Label1.Text = "Name: "
        ' 
        ' dgv
        ' 
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv.Location = New Point(35, 432)
        dgv.Name = "dgv"
        dgv.RowHeadersWidth = 62
        dgv.RowTemplate.Height = 33
        dgv.Size = New Size(807, 374)
        dgv.TabIndex = 1
        ' 
        ' txtEnterId
        ' 
        txtEnterId.BorderStyle = BorderStyle.FixedSingle
        txtEnterId.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point)
        txtEnterId.Location = New Point(1056, 440)
        txtEnterId.Name = "txtEnterId"
        txtEnterId.Size = New Size(80, 45)
        txtEnterId.TabIndex = 9
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Sitka Display", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.Location = New Point(896, 433)
        Label5.Name = "Label5"
        Label5.Size = New Size(151, 52)
        Label5.TabIndex = 8
        Label5.Text = "Enter ID"
        ' 
        ' btnSearch
        ' 
        btnSearch.BackColor = Color.Khaki
        btnSearch.Font = New Font("Sitka Small Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point)
        btnSearch.Location = New Point(906, 491)
        btnSearch.Name = "btnSearch"
        btnSearch.Size = New Size(180, 59)
        btnSearch.TabIndex = 10
        btnSearch.Text = "Search"
        btnSearch.UseVisualStyleBackColor = False
        ' 
        ' btnDelete
        ' 
        btnDelete.BackColor = Color.Khaki
        btnDelete.Font = New Font("Sitka Small Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point)
        btnDelete.Location = New Point(906, 576)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(180, 59)
        btnDelete.TabIndex = 11
        btnDelete.Text = "Delete"
        btnDelete.UseVisualStyleBackColor = False
        ' 
        ' btnAdd
        ' 
        btnAdd.BackColor = Color.Khaki
        btnAdd.Font = New Font("Sitka Small Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point)
        btnAdd.Location = New Point(35, 338)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(180, 59)
        btnAdd.TabIndex = 12
        btnAdd.Text = "Add"
        btnAdd.UseVisualStyleBackColor = False
        ' 
        ' btnUpdate
        ' 
        btnUpdate.BackColor = Color.Khaki
        btnUpdate.Font = New Font("Sitka Small Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point)
        btnUpdate.Location = New Point(239, 338)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(180, 59)
        btnUpdate.TabIndex = 13
        btnUpdate.Text = "Update"
        btnUpdate.UseVisualStyleBackColor = False
        ' 
        ' btnEdit
        ' 
        btnEdit.BackColor = Color.Khaki
        btnEdit.Font = New Font("Sitka Small Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point)
        btnEdit.Location = New Point(435, 338)
        btnEdit.Name = "btnEdit"
        btnEdit.Size = New Size(180, 59)
        btnEdit.TabIndex = 14
        btnEdit.Text = "Edit"
        btnEdit.UseVisualStyleBackColor = False
        ' 
        ' btnSave
        ' 
        btnSave.BackColor = Color.Khaki
        btnSave.Font = New Font("Sitka Small Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point)
        btnSave.Location = New Point(635, 338)
        btnSave.Name = "btnSave"
        btnSave.Size = New Size(180, 59)
        btnSave.TabIndex = 15
        btnSave.Text = "Save"
        btnSave.UseVisualStyleBackColor = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.LemonChiffon
        ClientSize = New Size(1183, 824)
        Controls.Add(btnSave)
        Controls.Add(btnEdit)
        Controls.Add(btnUpdate)
        Controls.Add(btnAdd)
        Controls.Add(btnDelete)
        Controls.Add(btnSearch)
        Controls.Add(txtEnterId)
        Controls.Add(dgv)
        Controls.Add(Label5)
        Controls.Add(GroupBox1)
        Name = "Form1"
        Text = "Form1"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        CType(dgv, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtContact As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents txtAge As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents dgv As DataGridView
    Friend WithEvents txtEnterId As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btnSearch As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnEdit As Button
    Friend WithEvents btnSave As Button
End Class
