﻿Imports System.Data.OleDb

Public Class Form1
    Dim conn As New OleDbConnection
    Dim cmd As New OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)
    Dim ds As New DataSet

    Public Sub ShowInUi()
        conn.Open()
        cmd = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        da = New OleDbDataAdapter("SELECT * FROM dbstudentForm", conn)
        ds = New DataSet()
        If dt IsNot Nothing Then
            dt.Clear()
        Else
            dt = New DataTable()
        End If
        da.Fill(ds, "dbstudentForm")
        dgv.DataSource = ds.Tables("dbstudentForm")
        conn.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim connString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\GWEN PROGRAMMING\PROGRAMMING\VB.NET\CC103 PROJECT FINAL\StudentForm\dbstudentForm.mdb"
        conn.ConnectionString = connString
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        ShowInUi()
    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim name As String = txtName.Text
        Dim age As String = txtAge.Text
        Dim address As String = txtAddress.Text
        Dim contact As String = txtContact.Text

        Try
            conn.Open()
            Dim queryInsert As String = "INSERT INTO dbstudentForm([Name], [Age], [Address], [Contact]) VALUES(@name, @age, @address, @contact)"
            cmd = New OleDbCommand(queryInsert, conn)
            cmd.Parameters.AddWithValue("@name", name)
            cmd.Parameters.AddWithValue("@age", age)
            cmd.Parameters.AddWithValue("@address", address)
            cmd.Parameters.AddWithValue("@contact", contact)
            cmd.ExecuteNonQuery()
            conn.Close()
            ShowInUi()

            txtName.Text = ""
            txtAge.Text = ""
            txtAddress.Text = ""
            txtContact.Text = ""
            MsgBox("Successfully Added In Database", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Notification")

        Catch ex As Exception
            MessageBox.Show("Error adding data: " & ex.Message)
            conn.Close()
        End Try
    End Sub


    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If dgv.SelectedRows.Count > 0 Then

            Dim Name As String = txtName.Text
            Dim Age As String = txtAge.Text
            Dim Address As String = txtAddress.Text
            Dim Contact As String = txtContact.Text

            Try
                conn.Open()
                Dim queryUpdate As String = "UPDATE dbstudentForm SET [Name] = @name, [Age] = @age, [Address] = @address, [Contact] = @contact WHERE [Name] = @name"
                cmd = New OleDbCommand(queryUpdate, conn)
                cmd.Parameters.AddWithValue("@name", Name)
                cmd.Parameters.AddWithValue("@age", Age)
                cmd.Parameters.AddWithValue("@address", Address)
                cmd.Parameters.AddWithValue("@contact", Contact)
                cmd.Parameters.AddWithValue("@name", Name)
                cmd.ExecuteNonQuery()
                conn.Close()
                ShowInUi()
                MsgBox("Record Updated", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Notification")
            Catch ex As Exception
                MessageBox.Show("Error updating record: " & ex.Message)
                conn.Close()
            End Try
        Else
            MessageBox.Show("Please select a row to update.")
        End If

    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If dgv.SelectedRows.Count > 0 Then

            Dim Name As String = txtName.Text
            Dim Age As String = txtAge.Text
            Dim Address As String = txtAddress.Text
            Dim Contact As String = txtContact.Text

            Try
                conn.Open()
                Dim queryUpdate As String = "UPDATE dbstudentForm SET [Name] = @name, [Age] = @age, [Address] = @address, [Contact] = @contact WHERE [Name] = @name"
                cmd = New OleDbCommand(queryUpdate, conn)
                cmd.Parameters.AddWithValue("@name", Name)
                cmd.Parameters.AddWithValue("@age", Age)
                cmd.Parameters.AddWithValue("@address", Address)
                cmd.Parameters.AddWithValue("@contact", Contact)
                cmd.Parameters.AddWithValue("@name", Name)
                cmd.ExecuteNonQuery()
                conn.Close()
                ShowInUi()
                MsgBox("Record Updated", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Notification")
            Catch ex As Exception
                MessageBox.Show("Error updating record: " & ex.Message)
                conn.Close()
            End Try
        Else
            MessageBox.Show("Please select a row to update.")
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            conn.Open()
            da.Update(dt)
            conn.Close()
            MsgBox("Changes Saved Successfully", MsgBoxStyle.Information, "Save")
        Catch ex As Exception
            MessageBox.Show("Error saving changes: " & ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim searchText As String = txtEnterId.Text.Trim()

        If searchText <> "" Then
            Try
                conn.Open()
                Dim querySearch As String = "SELECT * FROM dbstudentForm WHERE [ID] LIKE @SearchText OR [Name] LIKE @SearchText OR [Address] LIKE @SearchText"
                cmd = New OleDbCommand(querySearch, conn)
                cmd.Parameters.AddWithValue("@SearchText", "%" & searchText & "%")

                Dim dtSearch As New DataTable()
                dtSearch.Load(cmd.ExecuteReader())
                dgv.DataSource = dtSearch

                conn.Close()

                If dtSearch.Rows.Count = 0 Then
                    MsgBox("No matching records found.", MsgBoxStyle.Information, "Search")
                Else
                    MsgBox(dtSearch.Rows.Count & " record(s) found.", MsgBoxStyle.Information, "Search")
                End If
            Catch ex As Exception
                MessageBox.Show("Error searching records: " & ex.Message)
                conn.Close()
            End Try
        Else
            MessageBox.Show("Please enter a search term.", "Search")
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If dgv.SelectedRows.Count > 0 Then
            Dim selectedID = txtEnterId.Text


            conn.Open()
                Dim queryDelete As String = "DELETE FROM dbstudentForm WHERE ID = @ID"
                cmd = New OleDbCommand(queryDelete, conn)
                cmd.Parameters.AddWithValue("@ID", selectedID)
                cmd.ExecuteNonQuery()
                conn.Close()
                ShowInUi()
                MsgBox("Record Deleted", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Notification")

            conn.Close()

        Else
            MessageBox.Show("Please select a row to delete.")
        End If
    End Sub
End Class
